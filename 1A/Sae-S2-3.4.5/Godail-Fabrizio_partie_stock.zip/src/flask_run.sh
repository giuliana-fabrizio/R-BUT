export FLASK_APP=app
export FLASK_ENV=development
python -m flask run  --host 0.0.0.0
# flask run
